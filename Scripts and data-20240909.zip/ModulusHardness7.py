import pandas as pd
import matplotlib.pyplot as plt
import scipy.stats as st

EH = pd.read_csv("NanoindentationModulusHardness.csv")
st.probplot(EH["Elastic Modulus(GPa)"],dist="norm",plot=plt)
plt.show()
