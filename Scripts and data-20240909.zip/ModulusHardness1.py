import pandas as pd
import matplotlib.pyplot as plt

EH = pd.read_csv("NanoindentationModulusHardness.csv")
plt.scatter(EH["Elastic Modulus(GPa)"],EH["Hardness(GPa)"])
plt.xlabel("Elastic Modulus (GPa)")
plt.ylabel("Hardness (GPa)")
plt.show()
