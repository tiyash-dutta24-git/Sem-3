import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sbn

EH = pd.read_csv("NanoindentationModulusHardness.csv")
sbn.displot(data = EH, x="Elastic Modulus(GPa)",kde=True)
plt.xlabel("Elastic Modulus (GPa)")
plt.show()
