import pandas as pd
import matplotlib.pyplot as plt

EH = pd.read_csv("NanoindentationModulusHardness.csv")
EH["SMA"] = EH["Elastic Modulus(GPa)"].rolling(window=21).mean()
plt.plot(EH["Elastic Modulus(GPa)"],'o')
plt.plot(EH["SMA"])
plt.ylabel("Elastic Modulus (GPa)")
plt.show()
