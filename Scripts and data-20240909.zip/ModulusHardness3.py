import pandas as pd
import matplotlib.pyplot as plt

EH = pd.read_csv("NanoindentationModulusHardness.csv")
plt.hist(EH["Elastic Modulus(GPa)"])
plt.xlabel("Elastic Modulus (GPa)")
plt.ylabel("Count")
plt.show()
