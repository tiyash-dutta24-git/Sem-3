import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sbn
from seaborn_qqplot import pplot

EH = pd.read_csv("NanoindentationModulusHardness.csv")
pplot(data = EH, x="Elastic Modulus(GPa)",y="Hardness(GPa)",kind="qq")
plt.show()
