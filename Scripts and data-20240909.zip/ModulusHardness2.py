import pandas as pd
import matplotlib.pyplot as plt

EH = pd.read_csv("NanoindentationModulusHardness.csv")
plt.plot(EH["Elastic Modulus(GPa)"],'o')
plt.ylabel("Elastic Modulus (GPa)")
plt.show()
