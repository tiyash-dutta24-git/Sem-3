import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
import scipy.stats as st

EH = pd.read_csv("NanoindentationModulusHardness.csv")
mu = EH["Elastic Modulus(GPa)"].mean()
sigma = EH["Elastic Modulus(GPa)"].std()

pp = sm.ProbPlot(EH["Elastic Modulus(GPa)"],fit=True)
fig,ax = plt.subplots()
pp.ppplot(line="45",ax=ax)
plt.show()
